var monkey, monkeyImage, banana, bananaImage, obstacle, obstacleImage, count, background1, backgroundImage, obstacleGroup, bananaGroup, invisibleGround

function preload() {
  monkeyImage=loadAnimation('Monkey_01.png','Monkey_02.png','Monkey_03.png','Monkey_04.png','Monkey_05.png','Monkey_06.png','Monkey_07.png','Monkey_08.png','Monkey_09.png','Monkey_10.png')
  bananaImage=loadImage('banana.png')
  obstacleImage=loadImage('stone.png')
  backgroundImage=loadImage('jungle.jpg')
 }

function setup() {
  createCanvas(400, 400);
  monkey=createSprite(200,360,20,50);
  monkey.scale=0.45
  monkey.addAnimation('monkeyImage',monkeyImage)
  monkey.setCollider("circle",0,0,40);
  
invisibleGround = createSprite(200,365,400,5);
invisibleGround.visible = false;

obstaclesGroup = createGroup();
coinsGroup = createGroup();

count = 0
  
background1=createSprite(200,200)
background1.addImage(backgroundImage)
  
 
  
}

function draw() {
  background(220);
  
      if(keyDown("space")&& monkey.y >= 345){
      monkey.velocityY = -12 ;
    }
  
   monkey.velocityY = monkey.velocityY + 0.8;
  
  spawnCoins();
   spawnObstacles();
  
  if(obstaclesGroup.isTouching(monkey)){
     monkey.scale=0.45
   }
  
    if(bananaGroup.isTouching(monkey)){
     count=count+2
   }
  
  switch(count){
    case 10: player.scale=45
      break;
      case 20: player.scale=50
      break;
      case 30: player.scale=55
      break;
      case 40: player.scale=60
      break;
      case 50: player.scale=65
      break;
      default: break;
  }
    
  stroke("white");
textSize(20);
  fill("white")
  text("Score: "+score,500,50)
  
     background1.velocityX=-4
  
  if (background1.x<0){
    background1.x=background1.width/2
  
}

function spawnObstacles() {
  if(frameCount % 120 === 0) {
    var obstacle = createSprite(400,375,10,40);
    obstacle.velocityX = -6;
    obstacle.addImage(obstacleImage);
    
   
    
    
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.12;
    obstacle.lifetime = 70;
    //add each obstacle to the group
    obstaclesGroup.add(obstacle);
  }
}

function spawnCoins() {
  //write code here to spawn the clouds
  if (frameCount % 80 === 0) {
    var banana = createSprite(400,320,40,10);
    banana.y = 246;
    banana.setAnimation("Banana");
    banana.scale = 0.05;
    banana.velocityX = -3;
    
     //assign lifetime to the variable
    banana.lifetime = 134;
    
    //adjust the depth
    banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
    //add each cloud to the group
    bananaGroup.add(banana);
  }
}
}